
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function DosenTrayLanding() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-200 flex flex-col items-center justify-center p-4">
      <div className="max-w-2xl w-full text-center space-y-6">
        <h1 className="text-4xl font-bold text-gray-900">
          Das Dosen-Tray für die Rückgabe-Generation
        </h1>
        <p className="text-gray-600 text-lg">
          Schluss mit klebrigen Säcken und umfallenden Dosen. Unser stapelbares Tray transportiert bis zu 16 leere Dosen sauber, sicher und kompakt – und ist für verschiedene Dosengrößen (0,25 l bis 0,5 l) verfügbar.
        </p>

        <div className="grid grid-cols-2 gap-4">
          <img src="/images/CustomView25983052202.png" alt="Tray leer" className="rounded-2xl shadow" />
          <img src="/images/CustomView6286608304.png" alt="Tray mit Griff" className="rounded-2xl shadow" />
          <img src="/images/CustomView343343622.png" alt="Tray gestapelt" className="rounded-2xl shadow" />
          <img src="/images/CustomView16231477552.png" alt="Tray Anwendung" className="rounded-2xl shadow" />
        </div>

        <Card className="mt-8 p-4 bg-white shadow-xl rounded-2xl">
          <CardContent>
            <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-4">
              <Input
                type="email"
                placeholder="Deine E-Mail-Adresse"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
              <Button type="submit" className="w-full sm:w-auto">
                Benachrichtigen lassen
              </Button>
            </form>
            {submitted && (
              <p className="text-green-600 mt-2 text-sm">Danke! Du wirst benachrichtigt.</p>
            )}
          </CardContent>
        </Card>

        <div className="text-left text-gray-700 mt-8 space-y-2">
          <h2 className="text-xl font-semibold">Warum unser Tray?</h2>
          <ul className="list-disc list-inside">
            <li>Platzsparend stapelbar – Dose auf Dose, nicht Tray auf Tray</li>
            <li>Fixierung ohne Quetschen – ideal für Pfandrückgabe</li>
            <li>Sauber & wiederverwendbar – kein Auslaufen mehr</li>
            <li>Modernes Design für Rucksack, Fahrradkorb & WG-Küche</li>
            <li>Erhältlich für 0,25 l, 0,33 l und 0,5 l Dosen</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
