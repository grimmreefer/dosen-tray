
export default function Impressum() {
  return (
    <div className="p-8 max-w-3xl mx-auto text-gray-800">
      <h1 className="text-2xl font-bold mb-4">Impressum</h1>
      <p>Angaben gemäß § 5 ECG:</p>
      <p className="mt-2">
        Martin Jochum<br />
        Zangtalerstraße 31a<br />
        8570 Voitsberg<br />
        Österreich<br />
      </p>
      <p className="mt-4">Kontakt: info@jochum-3d-druckservice.at</p>
    </div>
  );
}
