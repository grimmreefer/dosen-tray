
import { Link } from 'react-router-dom';

export default function Footer() {
  return (
    <footer className="w-full text-center text-sm text-gray-500 mt-12 p-4 border-t">
      <p>
        <Link to="/impressum" className="underline">Impressum</Link> •{" "}
        <Link to="/datenschutz" className="underline">Datenschutz</Link> •{" "}
        Kontakt: info@jochum-3d-druckservice.at
      </p>
    </footer>
  );
}
