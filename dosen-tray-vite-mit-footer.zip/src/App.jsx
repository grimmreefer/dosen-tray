
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import DosenTrayLanding from './DosenTrayLanding.jsx';
import Impressum from './Impressum.jsx';
import Datenschutz from './Datenschutz.jsx';
import Footer from './Footer.jsx';

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<DosenTrayLanding />} />
        <Route path="/impressum" element={<Impressum />} />
        <Route path="/datenschutz" element={<Datenschutz />} />
      </Routes>
      <Footer />
    </Router>
  );
}
